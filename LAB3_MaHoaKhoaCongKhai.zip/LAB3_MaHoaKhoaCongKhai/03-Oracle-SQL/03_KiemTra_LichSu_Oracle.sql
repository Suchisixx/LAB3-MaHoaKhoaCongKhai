-- Co the chay bang tai khoan lab3_user HOAC SYS/SYSTEM (trong FREEPDB1) de kiem tra lich su
SELECT Id, Algorithm, Operation, InputLength, Success, CreatedAt
FROM lab3_user.History
ORDER BY Id DESC
FETCH FIRST 30 ROWS ONLY;

SELECT Algorithm, Operation, COUNT(*) AS SoLan
FROM lab3_user.History
GROUP BY Algorithm, Operation
ORDER BY Algorithm, Operation;
