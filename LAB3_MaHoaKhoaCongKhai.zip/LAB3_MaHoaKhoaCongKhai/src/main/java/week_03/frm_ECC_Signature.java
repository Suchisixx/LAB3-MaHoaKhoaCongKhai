package week_03;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_ECC_Signature extends JFrame {

    private final ECCSignature ecdsa = new ECCSignature();

    private JTextArea txt_public;
    private JTextArea txt_private;
    private JButton btn_generate;
    private JButton btn_savekeys;
    private JButton btn_loadkeys;
    private JTextArea txt_message;
    private JTextArea txt_signature;
    private JButton btn_sign;
    private JButton btn_verify;
    private JLabel lbl_result;
    private JLabel lbl_status;

    public frm_ECC_Signature() {
        initComponents();
        setLocationRelativeTo(null);
    }

    /** Hiện khóa công khai / khóa riêng (Base64) lên form. */
    private void showKeys() {
        txt_public.setText(ecdsa.getPublicKeyBase64());
        txt_private.setText(ecdsa.getPrivateKeyBase64());
        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }

    private void initComponents() {
        setTitle("ECDSA Signature");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(16, 18, 16, 18));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("CHỮ KÝ SỐ ECDSA (SHA256withECDSA)");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;

        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Public key:"), gbc);
        txt_public = new JTextArea(2, 50);
        txt_public.setLineWrap(true);
        txt_public.setEditable(false);
        JScrollPane spPub = new JScrollPane(txt_public);
        spPub.setPreferredSize(new Dimension(600, 46));
        gbc.gridx = 1;
        panel.add(spPub, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Private key:"), gbc);
        txt_private = new JTextArea(2, 50);
        txt_private.setLineWrap(true);
        txt_private.setEditable(false);
        JScrollPane spPri = new JScrollPane(txt_private);
        spPri.setPreferredSize(new Dimension(600, 46));
        gbc.gridx = 1;
        panel.add(spPri, gbc);

        JPanel keyBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btn_generate = new JButton("Generate Keys");
        btn_generate.setPreferredSize(new Dimension(140, 30));
        btn_generate.addActionListener(e -> btn_generateActionPerformed());
        btn_savekeys = new JButton("Save Keys");
        btn_savekeys.setPreferredSize(new Dimension(120, 30));
        btn_savekeys.addActionListener(e -> btn_savekeysActionPerformed());
        btn_loadkeys = new JButton("Load Keys");
        btn_loadkeys.setPreferredSize(new Dimension(120, 30));
        btn_loadkeys.addActionListener(e -> btn_loadkeysActionPerformed());
        keyBtns.add(btn_generate);
        keyBtns.add(btn_savekeys);
        keyBtns.add(btn_loadkeys);
        gbc.gridy = 3;
        gbc.gridx = 1;
        panel.add(keyBtns, gbc);

        gbc.gridy = 4;
        gbc.gridx = 0;
        panel.add(new JLabel("Message:"), gbc);
        txt_message = new JTextArea(2, 50);
        txt_message.setLineWrap(true);
        txt_message.setWrapStyleWord(true);
        JScrollPane spMsg = new JScrollPane(txt_message);
        spMsg.setPreferredSize(new Dimension(600, 56));
        gbc.gridx = 1;
        panel.add(spMsg, gbc);

        gbc.gridy = 5;
        gbc.gridx = 0;
        panel.add(new JLabel("Signature:"), gbc);
        txt_signature = new JTextArea(2, 50);
        txt_signature.setLineWrap(true);
        JScrollPane spSig = new JScrollPane(txt_signature);
        spSig.setPreferredSize(new Dimension(600, 56));
        gbc.gridx = 1;
        panel.add(spSig, gbc);

        JPanel opBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btn_sign = new JButton("Sign");
        btn_sign.setPreferredSize(new Dimension(110, 30));
        btn_sign.addActionListener(e -> btn_signActionPerformed());
        btn_verify = new JButton("Verify");
        btn_verify.setPreferredSize(new Dimension(110, 30));
        btn_verify.addActionListener(e -> btn_verifyActionPerformed());
        lbl_result = new JLabel("");
        lbl_result.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl_result.setPreferredSize(new Dimension(300, 38));
        opBtns.add(btn_sign);
        opBtns.add(btn_verify);
        opBtns.add(lbl_result);
        gbc.gridy = 6;
        gbc.gridx = 1;
        panel.add(opBtns, gbc);

        lbl_status = new JLabel("Bấm Generate Keys hoặc Load Keys.");
        lbl_status.setPreferredSize(new Dimension(600, 36));
        gbc.gridy = 7;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        panel.add(lbl_status, gbc);

        setContentPane(panel);
        pack();
    }

    private void btn_generateActionPerformed() {
        try {
            ecdsa.generateKeys();
            showKeys();
            lbl_status.setText("Đã tạo cặp khóa mới. Bản mã/chữ ký cũ sẽ không dùng được với khóa mới.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Không tạo được khóa: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_savekeysActionPerformed() {
        if (txt_public.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có khóa để lưu.");
            return;
        }
        String content = CryptoSupport.toKeyFile(txt_public.getText(), txt_private.getText());
        String path = FileTextIO.saveString(this, content, "ecdsa_keys.txt");
        if (path != null) {
            lbl_status.setText("Đã lưu khóa vào: " + path + " (giữ bí mật dòng PRIVATE).");
        }
    }

    private void btn_loadkeysActionPerformed() {
        String content = FileTextIO.openString(this);
        if (content == null) {
            return;
        }
        try {
            String[] keys = CryptoSupport.fromKeyFile(content);
            ecdsa.loadKeys(keys[0], keys[1]);
            txt_public.setText(keys[0]);
            txt_private.setText(keys[1]);
            lbl_status.setText("Đã nạp khóa từ tệp.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Tệp khóa không hợp lệ: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_signActionPerformed() {
        String message = txt_message.getText();
        try {
            txt_signature.setText(ecdsa.sign(message));
            lbl_result.setText("");
            lbl_status.setText("Đã ký bằng KHÓA RIÊNG. " + HistoryDao.tryInsert("ECDSA", "SIGN", message.length(), true));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ký thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btn_verifyActionPerformed() {
        String message = txt_message.getText();
        try {
            boolean ok = ecdsa.verify(message, txt_signature.getText());
            lbl_result.setText(ok ? "VALID" : "INVALID");
            lbl_result.setForeground(ok ? new Color(0, 128, 0) : Color.RED);
            lbl_status.setText("Đã xác minh bằng KHÓA CÔNG KHAI. "
                    + HistoryDao.tryInsert("ECDSA", "VERIFY", message.length(), ok));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Xác minh thất bại: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_ECC_Signature().setVisible(true));
    }
}
