package week_03;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class frm_Menu extends JFrame {

    private JButton btn_rsa;
    private JButton btn_ecc;
    private JButton btn_rsaaes;
    private JButton btn_signature;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 3 - Mã hóa khóa công khai");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(18, 22, 18, 22));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblTitle, gbc);

        JLabel lblSub = new JLabel("Chọn một bài để mở form tương ứng (bài 3.1 chạy RSADemo.java bằng Run File):");
        gbc.gridy = 1;
        panel.add(lblSub, gbc);

        JPanel grid = new JPanel(new GridLayout(2, 3, 12, 10));
        btn_rsa = makeBtn("3.2 RSA (Swing)", () -> new frm_RSA().setVisible(true));
        btn_ecc = makeBtn("3.3 ECC", () -> new frm_ECC().setVisible(true));
        btn_rsaaes = makeBtn("3.4 RSA + AES", () -> new frm_RSA_AES().setVisible(true));
        btn_signature = makeBtn("3.5 Chữ ký ECDSA", () -> new frm_ECC_Signature().setVisible(true));
        btn_sql = makeBtn("Kết nối Oracle", () -> new frm_KetNoiSQL().setVisible(true));
        btn_history = makeBtn("Xem lịch sử", () -> new frm_LichSu().setVisible(true));

        grid.add(btn_rsa);
        grid.add(btn_ecc);
        grid.add(btn_rsaaes);
        grid.add(btn_signature);
        grid.add(btn_sql);
        grid.add(btn_history);

        gbc.gridy = 2;
        gbc.insets = new Insets(10, 6, 6, 6);
        panel.add(grid, gbc);

        setContentPane(panel);
        pack();
    }

    private JButton makeBtn(String text, Runnable action) {
        JButton b = new JButton(text);
        b.setPreferredSize(new Dimension(200, 30));
        b.addActionListener(e -> action.run());
        return b;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
